cd /home/zoonimbus/zoonimbusProject/;
mvn exec:java -Dexec.mainClass="br.unb.cic.bionimbus.BioNimbus" -Dexec.args="-classpath %classpath br.unb.cic.bionimbus.BioNimbus" -Dexec.executable="java"
